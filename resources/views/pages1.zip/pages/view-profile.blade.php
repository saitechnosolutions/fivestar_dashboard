@extends('pages.layouts.default');
@section('title','Varan - Dashboard');
@section('main-content')

<div class="page-wrapper" style="margin-top:0px">
			<div class="page-content" style="padding-top:60px;background-image:url('');background-size:cover;background-attachment:fixed;background-repeat:no-repeat">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">User Profile</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">User Profilep</li>
							</ol>
						</nav>
					</div>

				</div>
				<!--end breadcrumb-->
				<div class="container">
					<div class="main-body">
						<div class="row">
							<div class="col-lg-4">
								<div class="card" style="position:fixed;width:25%">
									<div class="card-body">
										<div class="d-flex flex-column align-items-center text-center">
											<img src="../assets/images/avatars/avatar-2.png" alt="Admin" class="rounded-circle p-1 bg-primary" width="110">
											<div class="mt-3">
												<h4>{{$register->Name}}</h4>
												<p class="text-secondary mb-1">{{$register->job_category}}</p>
												<p class="text-muted font-size-sm">{{$register->district}}, {{$register->state}}</p>
												<p class="text-muted font-size-sm">{{$register->varan_id}}</p>
												<button class="btn btn-primary">Package name</button>
												<button class="btn btn-success">Approval</button>

											</div>
										</div>
										<hr class="my-4" />
										<ul class="list-group list-group-flush">
											<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
												<h6 class="mb-0">Mobile No</h6>
												<span class="text-secondary">{{$register->mobile_no}}</span>
											</li>
											<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
												<h6 class="mb-0">E-mail ID</h6>
												<span class="text-secondary">{{$register->email_id}}</span>
											</li>
											<li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
												<h6 class="mb-0">Whatsapp</h6>
												<span class="text-secondary">{{$register->whatsapp_no}}</span>
											</li>

										</ul>
									</div>
								</div>
							</div>
							<div class="col-lg-8">
								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Basic Details</h5>
										    <div class="row">
											<div class="col-sm-3">
												<h6 class="mb-0">Full Name</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->Name}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Created For</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->created_for}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Gender</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->Gender}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Date Of Birth</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->dob}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Age</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->age}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Mother Tongue</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->Monther_tongue}}" readonly/>
											</div>
											</div>
												<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Body Type</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->body_type}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Physical Status</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->physical_status}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Complexion</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->complexion}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Height</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->height}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Marital Status</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->marital_status}}" readonly/>
											</div>
											</div>

										</div>



									</div>

								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Religion Details</h5>
										    <div class="row">
											<div class="col-sm-3">
												<h6 class="mb-0">Religion</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->Religion}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Caste</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->Caste}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Sub Caste</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->sub_caste}}" readonly/>
											</div>
											</div>



											</div>

										</div>

								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Location Details</h5>
										    <div class="row">
											<div class="col-sm-3">
												<h6 class="mb-0">Address</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->com_address}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Country</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->country}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">State</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->state}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">District</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->district}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Municipality / Panchayat</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->municipality_panchayat}}" readonly/>
											</div>
											</div>



											</div>

										</div>

								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Professional Details</h5>
										    <div class="row">
											<div class="col-sm-3">
												<h6 class="mb-0">Education</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->eduction}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Education Detail</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->eduction_detail}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Job Category</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_category}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Job in Detail</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_detail}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Work Country</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_country}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Work State</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_state}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Work District</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_city}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Work City</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->job_city}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-3">
												<h6 class="mb-0">Annual Income</h6>
											</div>
											<div class="col-sm-9 text-secondary">
												<input type="text" class="form-control" value="{{$register->annual_income}}" readonly/>
											</div>
											</div>



											</div>

										</div>

								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Family Details</h5>
										    <div class="row">
											<div class="col-sm-4">
												<h6 class="mb-0">Father Name</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->father_name}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Father Job</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->father_occuption}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Mother Name</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->mother_name}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Mother Job</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->mother_occuption}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">No Of Siblings</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->total_sibblings}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">No of Elder Sister</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->elder_sister}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">No of Younger Sister</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->younger_sister}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">No of Elder Brother</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->elder_brother}}" readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">No of Younger Brother</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->younger_brother}}" readonly/>
											</div>
											</div>



											</div>

										</div>

								<div class="card">
									<div class="card-body">
									    <h5 class="mb-4">Horoscope Details</h5>
										    <div class="row">
											<div class="col-sm-4">
												<h6 class="mb-0">Zodiac</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control" value="{{$register->younger_brother}}" readonly/>
											</div>
											</div>
											<div class="row mb-3 mt-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Laknam</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control"  readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Stars</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control"  readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Birth Date</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control"  readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Birth Time</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control"  readonly/>
											</div>
											</div>
											<div class="row mb-3">
											<div class="col-sm-4">
												<h6 class="mb-0">Dhosam</h6>
											</div>
											<div class="col-sm-8 text-secondary">
												<input type="text" class="form-control"  readonly/>
											</div>
											</div>




											</div>

										</div>

									</div>
							</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

@endsection
