@extends('pages.layouts.default');
@section('title','Varan - Dashboard');
@section('main-content')

    <div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Pricing Tables</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Pricing Tables</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Add Packages</button>


						</div>
					</div>
				</div>
                @if(session()->get('success'))
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    {{session()->get('success')}}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                @endif
				<!--end breadcrumb-->
				<!-- Section: Pricing table -->
				<div class="pricing-table">

					<hr/>
					<div class="row ">
						<!-- Free Tier -->

                        <div class="table-responsive">

                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr>

                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Package Name</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Price</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 1</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 2</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 3</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 4</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 5</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 6</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 7</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 8</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 9</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Specification 10</th>
                                        <th class="text-center" style="word-wrap: break-word;min-width: 160px;max-width: 160px;">Edit</th>
                                        <th class="text-center">Delete</th>

                                    </tr>
                                </thead>
                                <tbody>
                                @if($package)

                                        @foreach ($package as $pack)

                                            <tr>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->package_name}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->package_price}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_1}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_2}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_3}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_4}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_5}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_6}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_7}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_8}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_9}}</td>
                                                <td class="text-center" style="vertical-align:middle">{{$pack->specification_10}}</td>
                                                <td class="text-center" style="vertical-align:middle"><a href="{{route('packages.edit',$pack->id)}}" class="btn btn-primary" style="padding:25px 15px 15px 15px;text-align:center"><i class="bx bx-pencil"></i></a></td>
                                                <td class="text-center" style="vertical-align:middle">
                                                    <form method="POST" action="{{route('packages.destroy',$pack->id)}}" onsubmit="return confirm('Do You want Delete this Data?')">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="btn btn-danger button">Delete</button>
                                                    </form>
                                                   </td>

                                            </tr>
                                        @endforeach
                                @endif


                                </tbody>

                            </table>
                        </div>

						<!-- Plus Tier -->

						<!-- Pro Tier -->

					</div>
					<!--end row-->


					<!--end row-->
				</div>
				<!-- Section: Pricing table -->
			</div>
		</div>

		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Package</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
            <form method="POST" action="{{route('packages.store')}}">
                @csrf
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_name" placeholder="Enter Package name">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package Price</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_price" placeholder="Package Price">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package Specification</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="specification_1" placeholder="Specification 1">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_2" placeholder="Specification 2">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_3" placeholder="Specification 3">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_4" placeholder="Specification 4">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_5" placeholder="Specification 5">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_6" placeholder="Specification 6">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_7" placeholder="Specification 7">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_8" placeholder="Specification 8">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_9" placeholder="Specification 9">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_10" placeholder="Specification 10">
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </form>
    </div>
  </div>
</div>
@endsection
