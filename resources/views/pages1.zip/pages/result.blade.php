@extends('pages.layouts.default');
@section('title','Varan - Dashboard');
@section('main-content')

<div class="page-wrapper">
    <div class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Search Results</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="/dashboard"><i class="bx bx-home-alt"></i></a>
                        </li>

                    </ol>
                </nav>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="main-body">
            <div class="row">

                @if ($register)

                        @foreach ($register as $profiles)
                        <div class="col-lg-4">
                            <div class="card" >
                                <div class="card-body">
                                    <div class="d-flex flex-column align-items-center text-center">
                                        <img src="../assets/images/avatars/avatar-2.png" alt="Admin" class="rounded-circle p-1 bg-primary" width="110">
                                        <div class="mt-3">
                                            <h4>{{$profiles->Name}}</h4>
                                            <p class="text-secondary mb-1">{{$profiles->job_category}}</p>
                                            <p class="text-muted font-size-sm">{{$profiles->district}}, {{$profiles->state}}</p>
                                            <p class="text-muted font-size-sm">{{$profiles->varan_id}}</p>
                                            {{-- <button class="btn btn-primary">Package name</button> --}}
                                            <button class="btn btn-success">View Details</button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        @endforeach
                @endif

            </div>
        </div>
    </div>
</div>
@endsection
