@extends('pages.layouts.default');
@section('title','Varan - Dashboard');
@section('main-content')

    <div class="page-wrapper">
			<div class="page-content">
				<!--breadcrumb-->
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="breadcrumb-title pe-3">Packages</div>
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>

							</ol>
						</nav>
					</div>

				</div>
                @if(session()->get('success'))
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    {{session()->get('success')}}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>
                @endif
				<!--end breadcrumb-->
				<!-- Section: Pricing table -->
				<div class="pricing-table">

					<hr/>
					<div class="row ">
						<!-- Free Tier -->
                        <div class=" col-lg-8 offset-lg-2">
                            <form method="POST" action="{{route('packages.update',$package->id)}}">
                                @csrf
                                @method('PATCH')
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Package name</label>
                                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_name" placeholder="Enter Package name" value="{{$package->package_name}}">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Package Price</label>
                                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_price" placeholder="Package Price" value="{{$package->package_price}}">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleFormControlInput1" class="form-label">Package Specification</label>
                                    <input type="text" class="form-control" id="exampleFormControlInput1" name="specification_1" placeholder="Specification 1" value="{{$package->specification_1}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_2" placeholder="Specification 2" value="{{$package->specification_2}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_3" placeholder="Specification 3" value="{{$package->specification_3}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_4" placeholder="Specification 4" value="{{$package->specification_4}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_5" placeholder="Specification 5" value="{{$package->specification_5}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_6" placeholder="Specification 6" value="{{$package->specification_6}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_7" placeholder="Specification 7" value="{{$package->specification_7}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_8" placeholder="Specification 8" value="{{$package->specification_8}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_9" placeholder="Specification 9" value="{{$package->specification_9}}">
                                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_10" placeholder="Specification 10" value="{{$package->specification_10}}">
                                </div>


                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                        </div>


						<!-- Plus Tier -->

						<!-- Pro Tier -->

					</div>
					<!--end row-->


					<!--end row-->
				</div>
				<!-- Section: Pricing table -->
			</div>
		</div>

		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Package</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
            <form method="POST" action="{{route('packages.store')}}">
                @csrf
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_name" placeholder="Enter Package name">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package Price</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="package_price" placeholder="Package Price">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Package Specification</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="specification_1" placeholder="Specification 1">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_2" placeholder="Specification 2">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_3" placeholder="Specification 3">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_4" placeholder="Specification 4">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_5" placeholder="Specification 5">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_6" placeholder="Specification 6">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_7" placeholder="Specification 7">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_8" placeholder="Specification 8">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_9" placeholder="Specification 9">
                    <input type="text" class="form-control mt-3" id="exampleFormControlInput1" name="specification_10" placeholder="Specification 10">
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
    </form>
    </div>
  </div>
</div>
@endsection
